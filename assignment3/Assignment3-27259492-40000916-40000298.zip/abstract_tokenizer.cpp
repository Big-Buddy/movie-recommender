#include "abstract_tokenizer.h"

abstract_tokenizer::abstract_tokenizer()
{
}

abstract_tokenizer::~abstract_tokenizer()
{
}
