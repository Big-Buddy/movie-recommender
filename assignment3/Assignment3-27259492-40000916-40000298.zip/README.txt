Alexandre Pelletier - 27259492
Martin Spasov - 40000916
Loic Huss - 40000298

Operating systems: Windows 10, Windows 7
IDE: CLion, Codeblocks
Compiler: GCC