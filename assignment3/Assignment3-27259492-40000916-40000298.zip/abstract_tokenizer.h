#ifndef ABSTRACT_TOKENIZER_H
#define ABSTRACT_TOKENIZER_H


class abstract_tokenizer
{
    public:
        //! @brief A default constructor.
        abstract_tokenizer();
        //! @brief A virtual destructor.
        virtual ~abstract_tokenizer();

};

#endif // ABSTRACT_TOKENIZER_H
