var classsentence =
[
    [ "sentence", "classsentence.html#a458e5abe0d27f8972771153e72667673", null ],
    [ "sentence", "classsentence.html#a39e99adb96c8de8aeff00c0657248f9e", null ],
    [ "~sentence", "classsentence.html#affdf5776454bd6796aac043ff8b9630e", null ],
    [ "getParentDocNum", "classsentence.html#a6b8b9942e1a30a75ca2308d6b71fb24d", null ],
    [ "getPos", "classsentence.html#ad4786351fceabfd06ca10b7766d516b3", null ],
    [ "operator<", "classsentence.html#ae4cbc4603c414be42f68131e243e1bed", null ]
];