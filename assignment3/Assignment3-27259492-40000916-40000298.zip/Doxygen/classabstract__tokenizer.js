var classabstract__tokenizer =
[
    [ "abstract_tokenizer", "classabstract__tokenizer.html#a03902af3bbdd717811b3eb56c9fc0060", null ],
    [ "~abstract_tokenizer", "classabstract__tokenizer.html#aa68856356e49784c7d0eed48d24f8738", null ]
];