var class_query___result =
[
    [ "Query_Result", "class_query___result.html#aca6caea4d2be58145212fc22c56a5fab", null ],
    [ "~Query_Result", "class_query___result.html#a12b2802d889af86623d0b1b646ca6854", null ],
    [ "generateEssayFromSentences", "class_query___result.html#a4729716b1a3d34c761a56d4d96ff906f", null ],
    [ "printDocResults", "class_query___result.html#a5a3054d05f8768e724886d3cae6970c1", null ],
    [ "query", "class_query___result.html#a444ded4e65dab7222256ed6591ff78d9", null ],
    [ "scorevector", "class_query___result.html#a4ef5504013529a3b61b1d064ad75b348", null ]
];