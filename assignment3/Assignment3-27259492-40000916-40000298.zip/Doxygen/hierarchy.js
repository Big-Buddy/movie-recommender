var hierarchy =
[
    [ "abstract_tokenizer", "classabstract__tokenizer.html", [
      [ "sentence_tokenizer", "classsentence__tokenizer.html", null ],
      [ "word_tokenizer", "classword__tokenizer.html", null ]
    ] ],
    [ "index_item", "classindex__item.html", [
      [ "document", "classdocument.html", null ],
      [ "sentence", "classsentence.html", null ]
    ] ],
    [ "indexer", "classindexer.html", [
      [ "document_indexer", "classdocument__indexer.html", null ]
    ] ],
    [ "Query_Result", "class_query___result.html", null ],
    [ "stopwords", "classstopwords.html", null ]
];