var classstopwords =
[
    [ "stopwords", "classstopwords.html#ae07cdf9173446ac3ff166c26ba7f05d4", null ],
    [ "~stopwords", "classstopwords.html#acc1fd23d272a96a69860f185360df992", null ],
    [ "stopwords", "classstopwords.html#a726865f116a88b84c2239e80a1fb872a", null ],
    [ "operator()", "classstopwords.html#a7e237ef49803d27b80d5efcca17f53b3", null ]
];