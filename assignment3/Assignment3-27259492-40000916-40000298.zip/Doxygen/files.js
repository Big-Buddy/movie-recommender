var files =
[
    [ "abstract_tokenizer.h", "abstract__tokenizer_8h_source.html", null ],
    [ "document.h", "document_8h_source.html", null ],
    [ "document_indexer.h", "document__indexer_8h_source.html", null ],
    [ "index_item.h", "index__item_8h_source.html", null ],
    [ "indexer.h", "indexer_8h_source.html", null ],
    [ "Query_Result.h", "_query___result_8h_source.html", null ],
    [ "sentence.h", "sentence_8h_source.html", null ],
    [ "sentence_tokenizer.h", "sentence__tokenizer_8h_source.html", null ],
    [ "stopwords.h", "stopwords_8h_source.html", null ],
    [ "word_tokenizer.h", "word__tokenizer_8h_source.html", null ]
];