var classdocument =
[
    [ "document", "classdocument.html#af1a85718219b8da6f1befaac0bf87989", null ],
    [ "~document", "classdocument.html#afff6a78ede7767d8cbc0cb4566ae64da", null ],
    [ "document", "classdocument.html#af8e0d4d3a3eeeac31022ebe0e76c5571", null ],
    [ "getDocNum", "classdocument.html#ac8755191462341296e2be04db6f8f4e5", null ],
    [ "name", "classdocument.html#a19e6fd5bb89537dc566df2eac658e5a6", null ],
    [ "operator<<", "classdocument.html#aafdf2f4ecb817252c0e22f7c072ec5b0", null ]
];