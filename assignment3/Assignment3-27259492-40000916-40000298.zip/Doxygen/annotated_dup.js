var annotated_dup =
[
    [ "abstract_tokenizer", "classabstract__tokenizer.html", "classabstract__tokenizer" ],
    [ "document", "classdocument.html", "classdocument" ],
    [ "document_indexer", "classdocument__indexer.html", "classdocument__indexer" ],
    [ "index_item", "classindex__item.html", "classindex__item" ],
    [ "indexer", "classindexer.html", "classindexer" ],
    [ "Query_Result", "class_query___result.html", "class_query___result" ],
    [ "sentence", "classsentence.html", "classsentence" ],
    [ "sentence_tokenizer", "classsentence__tokenizer.html", "classsentence__tokenizer" ],
    [ "stopwords", "classstopwords.html", "classstopwords" ],
    [ "word_tokenizer", "classword__tokenizer.html", "classword__tokenizer" ]
];