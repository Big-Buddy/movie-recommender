var searchData=
[
  ['printdocresults',['printDocResults',['../class_query___result.html#a5a3054d05f8768e724886d3cae6970c1',1,'Query_Result']]]
];
