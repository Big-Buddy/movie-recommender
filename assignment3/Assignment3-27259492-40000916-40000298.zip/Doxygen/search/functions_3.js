var searchData=
[
  ['index_5fitem',['index_item',['../classindex__item.html#a26948d7ad5975fe8160fdedb58df9904',1,'index_item']]],
  ['indexer',['indexer',['../classindexer.html#acbbcbad080a7ae43ed78840fcf006960',1,'indexer']]],
  ['is_5fend',['is_end',['../classsentence__tokenizer.html#accdc817790cdb696912ec8076701f8a9',1,'sentence_tokenizer']]],
  ['isabbreviation',['isAbbreviation',['../classsentence__tokenizer.html#a2f86e3437eb3a948b5ee309ce04d0029',1,'sentence_tokenizer']]],
  ['isnormalize',['isNormalize',['../classindexer.html#a48c05d99699e2191d606936b35ecbb0d',1,'indexer']]]
];
