var searchData=
[
  ['generateessayfromsentences',['generateEssayFromSentences',['../class_query___result.html#a4729716b1a3d34c761a56d4d96ff906f',1,'Query_Result']]],
  ['get_5fcontent',['get_content',['../classindex__item.html#ae95390ac357a5e10b6c1335a49d91e83',1,'index_item']]],
  ['getdft',['getDft',['../classindexer.html#a99c8633ff92270ecbe76a5c9cf57e2e0',1,'indexer']]],
  ['getdocnum',['getDocNum',['../classdocument.html#ac8755191462341296e2be04db6f8f4e5',1,'document']]],
  ['getdocumentnames',['getDocumentNames',['../classdocument__indexer.html#a885c965f69ed1fcef8b4670d48182045',1,'document_indexer']]],
  ['getitems',['getItems',['../classindexer.html#ad576259a08d87b8d4486793522a0ca5a',1,'indexer']]],
  ['getparentdocnum',['getParentDocNum',['../classsentence.html#a6b8b9942e1a30a75ca2308d6b71fb24d',1,'sentence']]],
  ['getpos',['getPos',['../classsentence.html#ad4786351fceabfd06ca10b7766d516b3',1,'sentence']]],
  ['getsize',['getSize',['../classindexer.html#ad9e5eee599f4677d7a6cca2f53aeec44',1,'indexer']]],
  ['getstpw',['getstpw',['../classindexer.html#a78be8aabef768ba82208956e53316cc5',1,'indexer']]],
  ['gettftd1',['getTFtd1',['../classindexer.html#ad2afffef1c97feb0c7934951ce35319c',1,'indexer']]],
  ['gettftd2',['getTFtd2',['../classindexer.html#ab819d6ad0ae7fb00254a5d41f4cc92cd',1,'indexer']]],
  ['gettotal1',['getTotal1',['../classindexer.html#a8886ee24d98c5129a6582a95f65e31f6',1,'indexer']]],
  ['gettotal2',['getTotal2',['../classindexer.html#a8717246599f696d38d2b7051071b8957',1,'indexer']]],
  ['getwtd',['getWtd',['../classindexer.html#a8c9a0dadc14a83bdfa36c8b7555cbc6c',1,'indexer']]]
];
