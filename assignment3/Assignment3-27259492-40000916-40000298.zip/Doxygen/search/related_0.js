var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classdocument.html#aafdf2f4ecb817252c0e22f7c072ec5b0',1,'document::operator&lt;&lt;()'],['../classdocument__indexer.html#aa4cd3fa3dc189d5e7dc4b07ed98958e8',1,'document_indexer::operator&lt;&lt;()']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classindexer.html#af6526a689e8ed16f67708180a988b8d8',1,'indexer']]]
];
