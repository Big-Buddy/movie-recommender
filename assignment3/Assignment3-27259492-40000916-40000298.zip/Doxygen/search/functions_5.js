var searchData=
[
  ['operator_28_29',['operator()',['../classstopwords.html#a7e237ef49803d27b80d5efcca17f53b3',1,'stopwords']]],
  ['operator_3c',['operator&lt;',['../classsentence.html#ae4cbc4603c414be42f68131e243e1bed',1,'sentence']]],
  ['operator_5b_5d',['operator[]',['../classdocument__indexer.html#a2f17781feae3360c3900190b69709f0d',1,'document_indexer::operator[](string name)'],['../classdocument__indexer.html#ab6573986790793c03f05192a526d217d',1,'document_indexer::operator[](int n)'],['../classindexer.html#ae71041fc84d94155473de60e4407d5cc',1,'indexer::operator[]()']]]
];
