var searchData=
[
  ['sentence',['sentence',['../classsentence.html',1,'']]],
  ['sentence_5ftokenizer',['sentence_tokenizer',['../classsentence__tokenizer.html',1,'']]],
  ['stopwords',['stopwords',['../classstopwords.html',1,'']]]
];
