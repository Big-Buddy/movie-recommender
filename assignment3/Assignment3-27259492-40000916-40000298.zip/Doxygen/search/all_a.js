var searchData=
[
  ['scorevector',['scorevector',['../class_query___result.html#a4ef5504013529a3b61b1d064ad75b348',1,'Query_Result']]],
  ['sentence',['sentence',['../classsentence.html',1,'sentence'],['../classsentence.html#a458e5abe0d27f8972771153e72667673',1,'sentence::sentence()'],['../classsentence.html#a39e99adb96c8de8aeff00c0657248f9e',1,'sentence::sentence(string s, int p, int docNum)']]],
  ['sentence_5ftokenize',['sentence_tokenize',['../classsentence__tokenizer.html#ab394b821c6d32d41ae07ae84a0d1b5a6',1,'sentence_tokenizer']]],
  ['sentence_5ftokenizer',['sentence_tokenizer',['../classsentence__tokenizer.html',1,'sentence_tokenizer'],['../classsentence__tokenizer.html#aa36679bc4afb2788d5c81fcee4ab9e0b',1,'sentence_tokenizer::sentence_tokenizer()']]],
  ['size',['size',['../classindex__item.html#a16fbb1fcb7c9296afd03eaed51175935',1,'index_item']]],
  ['stopwords',['stopwords',['../classstopwords.html',1,'stopwords'],['../classstopwords.html#ae07cdf9173446ac3ff166c26ba7f05d4',1,'stopwords::stopwords()'],['../classstopwords.html#a726865f116a88b84c2239e80a1fb872a',1,'stopwords::stopwords(string filename)']]],
  ['stpw',['stpw',['../classindexer.html#a627b020657c54f3c2ba35953311bf2b2',1,'indexer']]]
];
