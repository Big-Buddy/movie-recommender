var searchData=
[
  ['dft',['dft',['../classindexer.html#a4de4c0d5adaa7b61ccd81e83ecef5de0',1,'indexer']]],
  ['document',['document',['../classdocument.html',1,'document'],['../classdocument.html#af1a85718219b8da6f1befaac0bf87989',1,'document::document()'],['../classdocument.html#af8e0d4d3a3eeeac31022ebe0e76c5571',1,'document::document(string name, int num)']]],
  ['document_5findexer',['document_indexer',['../classdocument__indexer.html',1,'document_indexer'],['../classdocument__indexer.html#a569b5a1dc381efce6ab2ab64644a7662',1,'document_indexer::document_indexer()']]]
];
