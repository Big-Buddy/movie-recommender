var searchData=
[
  ['abstract_5ftokenizer',['abstract_tokenizer',['../classabstract__tokenizer.html',1,'abstract_tokenizer'],['../classabstract__tokenizer.html#a03902af3bbdd717811b3eb56c9fc0060',1,'abstract_tokenizer::abstract_tokenizer()']]]
];
