var searchData=
[
  ['query',['query',['../class_query___result.html#a444ded4e65dab7222256ed6591ff78d9',1,'Query_Result']]],
  ['query_5fresult',['Query_Result',['../class_query___result.html',1,'Query_Result'],['../class_query___result.html#aca6caea4d2be58145212fc22c56a5fab',1,'Query_Result::Query_Result()']]]
];
