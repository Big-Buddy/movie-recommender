var searchData=
[
  ['name',['name',['../classdocument.html#a19e6fd5bb89537dc566df2eac658e5a6',1,'document']]],
  ['normalize',['normalize',['../classindexer.html#afd19e249c5224de7b4b308c5420f2412',1,'indexer']]]
];
