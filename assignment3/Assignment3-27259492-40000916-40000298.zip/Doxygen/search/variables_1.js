var searchData=
[
  ['dft',['dft',['../classindexer.html#a4de4c0d5adaa7b61ccd81e83ecef5de0',1,'indexer']]]
];
