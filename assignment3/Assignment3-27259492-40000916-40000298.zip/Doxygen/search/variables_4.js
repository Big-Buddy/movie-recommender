var searchData=
[
  ['stpw',['stpw',['../classindexer.html#a627b020657c54f3c2ba35953311bf2b2',1,'indexer']]]
];
