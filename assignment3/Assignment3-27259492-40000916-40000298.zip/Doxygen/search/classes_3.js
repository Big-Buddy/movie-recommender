var searchData=
[
  ['query_5fresult',['Query_Result',['../class_query___result.html',1,'']]]
];
