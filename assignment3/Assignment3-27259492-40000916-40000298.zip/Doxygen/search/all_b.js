var searchData=
[
  ['tftd1',['tftd1',['../classindexer.html#a0139107164efd7e1d8ee95680a8f623e',1,'indexer']]],
  ['tftd2',['tftd2',['../classindexer.html#a1ff1c5347d49058577a4426c566fa869',1,'indexer']]],
  ['total1',['total1',['../classindexer.html#aa8fe5fc7623db3c099e9d1604ffa09bb',1,'indexer']]],
  ['total2',['total2',['../classindexer.html#a5b4ef5367c4d3f0f35b96c180c67e989',1,'indexer']]]
];
