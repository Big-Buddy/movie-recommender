var classsentence__tokenizer =
[
    [ "sentence_tokenizer", "classsentence__tokenizer.html#aa36679bc4afb2788d5c81fcee4ab9e0b", null ],
    [ "~sentence_tokenizer", "classsentence__tokenizer.html#ac15a8df6ebb233288866e8d692e514c8", null ],
    [ "is_end", "classsentence__tokenizer.html#accdc817790cdb696912ec8076701f8a9", null ],
    [ "isAbbreviation", "classsentence__tokenizer.html#a2f86e3437eb3a948b5ee309ce04d0029", null ],
    [ "sentence_tokenize", "classsentence__tokenizer.html#ab394b821c6d32d41ae07ae84a0d1b5a6", null ]
];