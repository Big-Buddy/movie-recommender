var classindexer =
[
    [ "Exceptions", "classindexer.html#aeadc68a96ef7492b4d320eaf470fb5f6", [
      [ "INDEX_NOT_NORMALIZED", "classindexer.html#aeadc68a96ef7492b4d320eaf470fb5f6afd84ddc9a3491bbddd77958c5c0c42c1", null ]
    ] ],
    [ "indexer", "classindexer.html#acbbcbad080a7ae43ed78840fcf006960", null ],
    [ "~indexer", "classindexer.html#acc872b85bb2520b0cf803801811c9e58", null ],
    [ "getDft", "classindexer.html#a99c8633ff92270ecbe76a5c9cf57e2e0", null ],
    [ "getItems", "classindexer.html#ad576259a08d87b8d4486793522a0ca5a", null ],
    [ "getSize", "classindexer.html#ad9e5eee599f4677d7a6cca2f53aeec44", null ],
    [ "getstpw", "classindexer.html#a78be8aabef768ba82208956e53316cc5", null ],
    [ "getTFtd1", "classindexer.html#ad2afffef1c97feb0c7934951ce35319c", null ],
    [ "getTFtd2", "classindexer.html#ab819d6ad0ae7fb00254a5d41f4cc92cd", null ],
    [ "getTotal1", "classindexer.html#a8886ee24d98c5129a6582a95f65e31f6", null ],
    [ "getTotal2", "classindexer.html#a8717246599f696d38d2b7051071b8957", null ],
    [ "getWtd", "classindexer.html#a8c9a0dadc14a83bdfa36c8b7555cbc6c", null ],
    [ "isNormalize", "classindexer.html#a48c05d99699e2191d606936b35ecbb0d", null ],
    [ "normalize", "classindexer.html#afd19e249c5224de7b4b308c5420f2412", null ],
    [ "operator[]", "classindexer.html#ae71041fc84d94155473de60e4407d5cc", null ],
    [ "operator>>", "classindexer.html#af6526a689e8ed16f67708180a988b8d8", null ],
    [ "dft", "classindexer.html#a4de4c0d5adaa7b61ccd81e83ecef5de0", null ],
    [ "items", "classindexer.html#a3b00610add9f8f127eb1c1a22e8d7886", null ],
    [ "N", "classindexer.html#a0742c29a845289118c3f4b75653be72c", null ],
    [ "normalized", "classindexer.html#a8c6e10131bfdffba3d221076176a16c7", null ],
    [ "stpw", "classindexer.html#a627b020657c54f3c2ba35953311bf2b2", null ],
    [ "tftd1", "classindexer.html#a0139107164efd7e1d8ee95680a8f623e", null ],
    [ "tftd2", "classindexer.html#a1ff1c5347d49058577a4426c566fa869", null ],
    [ "total1", "classindexer.html#aa8fe5fc7623db3c099e9d1604ffa09bb", null ],
    [ "total2", "classindexer.html#a5b4ef5367c4d3f0f35b96c180c67e989", null ],
    [ "wtd", "classindexer.html#a74d1cf4b9a28f2772334d2abadab014d", null ]
];